import { handle } from "./api.ts";
import { ingestAll } from "./ingest.ts";

export default {
  async fetch(req: Request, env: any, ctx: any): Promise<Response> {
    try {
      return await handle(req, env, ctx);
    } catch (e: any) {
      console.error("api_error", e?.message || e);
      return new Response(JSON.stringify({ error: "error_interno" }), { status: 500, headers: { "content-type": "application/json" } });
    }
  },
  async scheduled(_event: unknown, env: any, ctx: { waitUntil(p: Promise<unknown>): void }) {
    ctx.waitUntil(ingestAll(env));
  },
};
