import { ingestAll } from "./ingest.ts";

const json = (data: unknown, status = 200, maxAge = 0) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": maxAge ? `public, max-age=${maxAge}` : "no-store",
      "x-content-type-options": "nosniff",
    },
  });

function nextCron(now = new Date()) {
  const d = new Date(now);
  d.setUTCSeconds(0, 0);
  d.setUTCMinutes(d.getUTCMinutes() < 30 ? 30 : 60);
  return d.toISOString();
}
function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
const clampInt = (v: string | null, def: number, min: number, max: number) => Math.min(Math.max(Number(v) || def, min), max);

export async function handle(req: Request, env: any, ctx: { waitUntil(p: Promise<unknown>): void }): Promise<Response> {
  const url = new URL(req.url);
  const p = url.pathname;
  const q = url.searchParams;

  if (p === "/api/admin/ingest" && req.method === "POST") {
    if (!env.ADMIN_TOKEN) return json({ error: "admin_no_configurado" }, 503);
    const tok = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
    if (!safeEq(tok, env.ADMIN_TOKEN)) return json({ error: "no_autorizado" }, 401);
    ctx.waitUntil(ingestAll(env, true));
    return json({ ok: true, mensaje: "Ingesta forzada iniciada. Revisá /api/status en unos instantes." }, 202);
  }

  if (p === "/api/health") {
    const a = await env.DB.prepare("SELECT COUNT(*) AS total, MAX(ingested_at) AS last_ingested FROM articles").first();
    return json({ ok: true, articles: a, time: new Date().toISOString() });
  }

  if (p === "/api/status") {
    const sources = (await env.DB.prepare("SELECT id, slug, name, adapter, source_type, reliability, enabled, poll_interval_min, last_success_at, last_error, consecutive_failures FROM sources ORDER BY id").all()).results;
    const runs = (await env.DB.prepare("SELECT r.source_id, r.started_at, r.duration_ms, r.fetched, r.inserted, r.duplicates, r.status, r.error FROM ingest_runs r WHERE r.id IN (SELECT MAX(id) FROM ingest_runs GROUP BY source_id)").all()).results;
    const by: Record<number, any> = Object.fromEntries(runs.map((r: any) => [r.source_id, r]));
    const tot = await env.DB.prepare("SELECT (SELECT COUNT(*) FROM articles) AS articles, (SELECT COUNT(*) FROM articles WHERE ingested_at >= datetime('now','-1 day')) AS articles_24h, (SELECT COUNT(*) FROM articles WHERE translation_status = 'pending') AS pending_translation, (SELECT COUNT(*) FROM cves) AS cves, (SELECT COUNT(*) FROM cves WHERE in_kev = 1) AS kev, (SELECT COUNT(*) FROM ingest_runs) AS runs, (SELECT MAX(started_at) FROM ingest_runs) AS last_run").first();
    const latest = await env.DB.prepare("SELECT a.id, a.original_title, a.title_es, a.ingested_at, a.published_at, s.name AS source FROM articles a JOIN sources s ON s.id = a.source_id ORDER BY a.id DESC LIMIT 1").first();
    return json({
      generated_at: new Date().toISOString(),
      next_run_estimate: nextCron(),
      next_run_note: "Según el cron configurado (cada 30 min); cada fuente se consulta cuando vence su intervalo.",
      totals: tot, latest_article: latest,
      sources: sources.map((s: any) => ({ ...s, last_run: by[s.id] ?? null })),
    });
  }

  if (p === "/api/stats") {
    const days = clampInt(q.get("days"), 30, 7, 90);
    const src = Object.fromEntries((await env.DB.prepare("SELECT slug, last_success_at FROM sources WHERE slug IN ('cisa-kev','nvd')").all()).results.map((r: any) => [r.slug, r.last_success_at]));
    const art = (await env.DB.prepare("SELECT date(ingested_at) AS d, COUNT(*) AS n FROM articles WHERE ingested_at >= datetime('now', ?1) GROUP BY d ORDER BY d").bind(`-${days} days`).all()).results;
    const kev = (await env.DB.prepare("SELECT kev_added_at AS d, COUNT(*) AS n FROM cves WHERE in_kev = 1 AND kev_added_at >= date('now', ?1) GROUP BY d ORDER BY d").bind(`-${days} days`).all()).results;
    const sev = (await env.DB.prepare("SELECT COALESCE(severity,'SIN DATO') AS d, COUNT(*) AS n FROM cves WHERE source LIKE 'nvd%' AND published_at >= datetime('now', ?1) GROUP BY d ORDER BY n DESC").bind(`-${days} days`).all()).results;
    const last = await env.DB.prepare("SELECT MAX(ingested_at) AS t FROM articles").first();
    return json({
      window_days: days, generated_at: new Date().toISOString(),
      series: {
        articles_ingested: { title: "Noticias ingeridas por día", measures: "Artículos incorporados a la base por nuestras ingestas, agrupados por fecha de ingesta (UTC). No mide ataques ocurridos.", unit: "artículos/día", source: "Fuentes RSS habilitadas del registro de fuentes", updated_at: last?.t ?? null, limitations: "Depende de las fuentes habilitadas y de la cobertura de sus feeds; los primeros días reflejan la puesta en marcha, no el volumen real del sector.", rows: art },
        kev_added: { title: "Vulnerabilidades añadidas al catálogo KEV", measures: "CVE que CISA incorporó al catálogo de vulnerabilidades explotadas, por fecha de incorporación.", unit: "CVE/día", source: "CISA Known Exploited Vulnerabilities (JSON oficial)", updated_at: src["cisa-kev"] ?? null, limitations: "Cuenta registros del catálogo, no incidentes. La carga inicial es gradual (hasta 400 registros por ejecución), por lo que ventanas antiguas pueden estar incompletas.", rows: kev },
        cves_by_severity: { title: "CVE publicadas por severidad", measures: "CVE publicadas en la ventana, según la severidad CVSS que informa NVD.", unit: "CVE", source: "NVD API 2.0 (NIST)", updated_at: src["nvd"] ?? null, limitations: "Solo incluye CVE sincronizadas desde que se activó la ingesta; la severidad CVSS no mide riesgo real ni explotación.", rows: sev },
      },
    }, 200, 120);
  }

  if (p === "/api/cves") {
    const where: string[] = [], binds: any[] = [];
    if (q.get("kev") === "1") where.push("in_kev = 1");
    const sev = q.get("severity");
    if (sev && /^[A-Za-z]{3,10}$/.test(sev)) { binds.push(sev.toUpperCase()); where.push(`severity = ?${binds.length}`); }
    const text = q.get("q");
    if (text) { binds.push(`%${text.slice(0, 60).replace(/[%_]/g, "")}%`); where.push(`(cve_id LIKE ?${binds.length} OR description_en LIKE ?${binds.length})`); }
    const limit = clampInt(q.get("limit"), 20, 1, 50);
    const rows = (await env.DB.prepare(`SELECT cve_id, description_en, cvss_score, cvss_version, severity, published_at, last_modified_at, cwe, in_kev, kev_added_at, source, synced_at FROM cves ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY COALESCE(kev_added_at, published_at) DESC LIMIT ${limit}`).bind(...binds).all()).results;
    return json({ items: rows, limit }, 200, 60);
  }

  if (p === "/api/actors") {
    const rows = (await env.DB.prepare("SELECT attack_id, name, aliases, description, url, attack_version FROM actors ORDER BY name").all()).results;
    const m = Object.fromEntries((await env.DB.prepare("SELECT entity_id, COUNT(*) AS n, MAX(created_at) AS last FROM article_entities WHERE entity_type = 'actor' GROUP BY entity_id").all()).results.map((r: any) => [r.entity_id, r]));
    return json({
      items: rows.map((a: any) => ({ ...a, aliases: JSON.parse(a.aliases || "[]"), mentions: m[a.attack_id]?.n ?? 0, last_mention_ingested: m[a.attack_id]?.last ?? null })),
      note: "Perfiles de la base de conocimiento ATT&CK. Su existencia no indica actividad reciente; 'mentions' cuenta noticias ingeridas que nombran al grupo, no ataques ni atribuciones confirmadas.",
    }, 200, 300);
  }

  const m = p.match(/^\/api\/articles\/(\d+)$/);
  if (m) {
    const a = await env.DB.prepare("SELECT a.*, s.name AS source_name, s.url AS source_url, s.reliability FROM articles a JOIN sources s ON s.id = a.source_id WHERE a.id = ?1").bind(Number(m[1])).first();
    if (!a) return json({ error: "no_encontrado" }, 404);
    const cats = (await env.DB.prepare("SELECT category FROM article_categories WHERE article_id = ?1").bind(a.id).all()).results.map((r: any) => r.category);
    const ents = (await env.DB.prepare("SELECT e.entity_type, e.entity_id, e.evidence_status, e.provenance, ac.name AS actor_name, ac.url AS actor_url FROM article_entities e LEFT JOIN actors ac ON e.entity_type = 'actor' AND ac.attack_id = e.entity_id WHERE e.article_id = ?1").bind(a.id).all()).results;
    return json({ ...a, categories: cats, entities: ents }, 200, 60);
  }

  if (p === "/api/articles") {
    const limit = clampInt(q.get("limit"), 20, 1, 50), offset = clampInt(q.get("offset"), 0, 0, 5000);
    const rows = (await env.DB.prepare(
      `SELECT a.id, a.canonical_url, a.original_title, a.title_es, a.summary_es, a.original_excerpt, a.published_at, a.ingested_at, a.translation_status, a.status, s.name AS source,
              (SELECT group_concat(category, '|') FROM article_categories c WHERE c.article_id = a.id) AS categories
       FROM articles a JOIN sources s ON s.id = a.source_id WHERE a.status IN ('draft','published')
       ORDER BY COALESCE(a.published_at, a.ingested_at) DESC LIMIT ?1 OFFSET ?2`).bind(limit, offset).all()).results;
    return json({ items: rows, limit, offset }, 200, 60);
  }

  return json({ error: "no_encontrado" }, 404);
}
